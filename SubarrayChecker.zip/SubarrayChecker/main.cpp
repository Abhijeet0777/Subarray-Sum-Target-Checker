#include <iostream>
#include <vector>
using namespace std;

bool hasSubarrayWithSum(const vector<int>& arr, int target) {
    int start = 0, sum = 0;

    for (int end = 0; end < arr.size(); ++end) {
        sum += arr[end];
        while (sum > target && start <= end)
            sum -= arr[start++];

        if (sum == target)
            return true;
    }
    return false;
}

int main() {
    int n, target;
    cout << "Enter number of elements in the array: ";
    cin >> n;

    vector<int> arr(n);
    cout << "Enter " << n << " elements:\n";
    for (int i = 0; i < n; ++i)
        cin >> arr[i];

    cout << "Enter the target sum: ";
    cin >> target;

    if (hasSubarrayWithSum(arr, target))
        cout << "Yes, subarray with target sum exists.\n";
    else
        cout << "No, such subarray does not exist.\n";

    return 0;
}